class Search {
  constructor() {
    alert("hello, I am a search");
  }
}

export default Search;